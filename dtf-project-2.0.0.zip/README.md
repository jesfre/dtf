dtf | Dextra Testing Framework
===
Dextra Testing Framework is a set of projects with tools and libraries that works together as a guideline to support automation testing with Selenium in an easiest way than the Selenium manner.

This project has been released by Dextra Technologies as OpenSource under the MIT license.

Requirements
===
Java 6+
Maven 3+

Build Outputs
===
For each Maven module of the project builds a JAR file. The outputs are placed under a relative /target folder of the project with the target name. In other words, the modules follow the Maven conventios. This is described with an example. For the project: dtf-api, the tarjet name in the POM is dtf-api so, the path of the output file will be dtf-api/target/dtf-api-<version>.jar
